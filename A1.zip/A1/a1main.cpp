#include "PlayList.h"
#include "Song.h"
#include <stdio.h>
#include <iostream>
using namespace std;

void displayAll (PlayList* pl)
{
    for (int i = 0; i < pl->size(); i++)
        cout << " " << i + 1 << " " << pl->get(i).getName() << " (" << pl->get(i).getArtist() << ") " << pl->get(i).getLength() << "s" << endl;
    cout << "There are " << pl->size() << " songs in the play list." << endl;
    return;
}
void newSong(PlayList* pl)
{
    string name = "";
    string artist = "";
    int time = 0;
    int pos;
    cout << "Song name: ";
    cin >> name;
    cout << "Artist: ";
    cin >> artist;
    cout << "Length: ";
    cin >> time;
    Song newsong = Song(name, artist, time);
    if (pl->size() == 0)
    {
        cout << "Position (1): ";
        cin >> pos;
    }
    else
    {
        cout << "Position (1 to " << pl->size()+1 << "): ";
        cin >> pos;
    }
    pl->insert(newsong, pos - 1);
    cout << "You entered " << name << " at position " << pos << " in the play list" << endl;
    return;
}

void remove(PlayList* pl)
{
    int rmvIndx;
    cout << "The index of song you want to remove: ";
    cin >> rmvIndx;
    pl->remove(rmvIndx-1);
    return;
}

int main()
{
    PlayList* playL = new PlayList();
    cout << "Menu:\n1 - Enter a song in the play list at a given position\n2 - Remove a song from the play list at a given position\n3 - Swap two songs in the play list\n4 - Print all the songs in the play list\n5 - Quit" << endl;
    char input = 0;
    bool finish = false;
// Menu continues to display to the user untill they choose to exit
    while (finish == false)
    {
        cout << endl;
        cout << "Enter 1 (insert), 2 (remove), 3 (swap), 4 (print) or 5 (quit): ";
        cin >> input;
        switch (input)
        {
            case '1':
            {
                newSong(playL);
                break;
            }
            case '2':
            {    
                remove(playL); 
                break;
            }
            case '3':
            {
                swap(playL);
                break;
            }
            case '4':
            {
                displayAll(playL);
                break;
            }
            case '5':
            {
                cout << "You have chosen to quit the program." << endl;
                finish = true;
                break;
            }
            default: cout << "Invalid input, try again!" << endl;
        }
    }
    return 0;
}
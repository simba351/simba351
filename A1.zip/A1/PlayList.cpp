// Write your name and date here
#include "PlayList.h"
#include <iostream>
using namespace std;

// PlayList method implementations go here

    // Constructors and destructor
	// POST: head of list is set to nullptr
	PlayList::PlayList()
    {
        this->head = nullptr;
        elementCount = 0;
    }

	// PARAM: pl - PlayList to be copied
	// POST: new PlayList is created that is a deep copy of pl
	PlayList::PlayList(const PlayList& pl)
    {
        PlayListNode* currentpl = pl.head;
        PlayListNode* current = this->head;
        while(currentpl != nullptr)
        {
            current = new PlayListNode(currentpl->song);
            current = current->next;
            currentpl = currentpl->next;
        }
        return;
    }
	
	// POST: dynamic memory associated with object is deallocated
	PlayList::~PlayList()
    {

    }

	// PARAM: pl - PlayList to be copied
	// POST: dynamic memory of calling object deallocated (except
	//       under self-assignment), calling object is set to a
	//       a deep copy of pl
	PlayList& PlayList::operator = (const PlayList & pl)
    {
        PlayList newPlaylist = PlayList(pl);
        this->head = newPlaylist.head;
    }

	// Mutators
	// PRE: 0 <= i <= length of list
	// PARAM: pos - 0-based insertion position
	//        sng - Song to be insertedpos
	void PlayList::insert(Song sng, unsigned int pos)
    {
        if (pos < 0 || pos > this->size())
            abort();
        if (this->size() == 0)
        {
            this->head = new PlayListNode(sng);
        }
        else if(pos == this->size())
        {
            PlayListNode* current = this->head;
            while (current->next != nullptr){current = current->next;}
            current->next = new PlayListNode(sng);
        }
        else if(pos == 0)
        {
            PlayListNode* nxt = this->head;
            this->head = new PlayListNode(sng, nxt);
        }
        else
        {
            PlayListNode* current = this->head;
            for (int index = 0; index < pos - 1; index++)
            {
                current = current->next;
            }
            PlayListNode* nxt = current->next;
            current->next = new PlayListNode(sng, nxt);
        }
        this->elementCount++;
        return;
    }

	// PRE: 0 <= pos <= length of list-1
	// PARAM: pos - 0-based position of element to be removed and returned
	// POST: Song at position pos is removed and returned
	Song PlayList::remove(unsigned int pos)
    {
        if (pos >= 0 && pos < this->size())
        {
            PlayListNode* current = this->head;
            PlayListNode* pre = NULL;
            for (int index = 0; index < pos; index++)
            {
                pre = current;
                current = current->next;
            }
            Song removedSong = current->song;
            //current = current->next;
            pre->next=current->next;
            this->elementCount--;
            return removedSong;
        }
        abort();
    }

	// PRE: 0 <= pos1, pos2 <= length of list-1
	// PARAM: pos1, pos2 - 0-based positions of elements to be swapped
	// POST: Songs at positions pos1 and pos2 are swapped
	void PlayList::swap(unsigned int pos1, unsigned int pos2)
    {
        if ((pos1 < 0 || pos1 >= this->size())||(pos2 < 0 || pos2 >= this->size())) return;
        PlayListNode* current1 = this->head;
        PlayListNode* current2 = this->head;
        for (int index = 0; index < pos1; index++) {current1 = current1->next;}
        for (int index = 0; index < pos2; index++) {current2 = current2->next;}
        Song temp = current1->song;
        current1->song = current2->song;
        current2->song = temp;
        return;
    }

	// Accessor
	// PRE: 0 <= pos <= length of list-1
	// PARAM: pos - 0-based position of element to be removed and returned
	// POST: returns the Song at position pos
	Song PlayList::get(unsigned int pos) const
    {
        if (pos < 0 || pos >= this->size())
            abort();
        PlayListNode* current = this->head;
        for (int index = 0; index < pos; index++){current = current->next;}
        return current->song;
    }

	// POST: returns the number of songs in the PlayList
	unsigned int PlayList::size() const
    {
        return this->elementCount;
    }
#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include <string.h>

#include "assignment4.h"

/* Question 1 */

int queue_move(queue_t* destination, queue_t* source) {
  // implement me
  return 0;
}

int queue_size(queue_t* q) {
  // implement me
  return 0;
}

bool queue_equal(queue_t* q1, queue_t* q2) {
  // implement me
  return false;
}

/* Question 2 */

float eval_arithmetic_expression(BTnode_t* root) {
  // implement me
  return 0;
}


/* Question 3 */

BTnode_t* find(BTnode_t* root, bool (*pred)(int)) {
  // implement me
  return NULL;
}

BTnode_t* create_mirror_tree(BTnode_t* root) {
  // implement me
  return NULL;
}


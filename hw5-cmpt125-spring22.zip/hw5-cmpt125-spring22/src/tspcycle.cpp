#include <iostream>

#include "tspcycle.hpp"

TSPCycle::TSPCycle() {
  m_points.clear();
}

// returns the length of the cycle
float TSPCycle::getLength() const {
  float ans=0;
  for(int i=0;i<m_points.size()-1;i++)
    ans+=m_points[i].getDistance(m_points[i+1]);
  ans+=m_points[0].getDistance(m_points[m_points.size()-1]);
  return ans;
}

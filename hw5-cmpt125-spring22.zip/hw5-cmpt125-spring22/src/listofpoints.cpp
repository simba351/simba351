#include "listofpoints.hpp"

ListOfPoints::ListOfPoints() {
  m_points.clear();
  return;
}

void ListOfPoints::addAfter(Point& newPt, string name) 
{
    for(auto it=m_points.begin();it!=m_points.end();it++)
    {
        if((*it).m_name==name)
        {
            it++;
            m_points.insert(it,newPt);
            break;
        }
    }
    return;
}

void ListOfPoints::addPoint(Point& newPt)  
{
    m_points.push_back(newPt);
    return;
}

Point& ListOfPoints::getPointAt(unsigned int i) {
  return m_points[i];
}

int ListOfPoints::getSize() const {
  return m_points.size();
}

void ListOfPoints::printList() const {
  for(auto it=m_points.begin();it!=m_points.end();it++)
    cout<<(*it)<<endl;
  return;
}

void ListOfPoints::draw() const {
  string Data[22][22];
  for(int i=0;i<=20;i++)
    for(int j=0;j<=20;j++)
      Data[i][j]="_";
  for(auto it=m_points.begin();it!=m_points.end();it++)
  {
    Data[(*it).getX()][(*it).getY()]=(*it).getName();
  }
  for(int i=20;i>=0;i--)
  {
    for(int j=0;j<=20;j++)
      cout<<Data[j][i];
    cout<<endl;
  }
}
 

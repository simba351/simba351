#include "tspsolver.hpp"
#include <algorithm>

TSPSolver::TSPSolver(ListOfPoints &list) {
  for(auto it=list.m_points.begin();it!=list.m_points.end();it++)
  {
    m_list.m_points.push_back((*it));
  }
}

void TSPSolver::solve() {
  int t0t=m_list.m_points.size();
  m_solution.m_points.clear();
  if(t0t>=1) m_solution.m_points.push_back(m_list.m_points[0]);
  if(t0t>=2) m_solution.m_points.push_back(m_list.m_points[1]);
  if(t0t>=3) m_solution.m_points.push_back(m_list.m_points[2]);
  for(int i=3;i<t0t;i++)
  {
    int now=0; int minn=99999; int crt=-1;
    for(int j=0;j<i;j++)
    {
      if(j==i-1) 
      {
        now=m_solution.m_points[j].getDistance(m_list.m_points[i])
          + m_list.m_points[i].getDistance(m_solution.m_points[0])
          - m_solution.m_points[j].getDistance(m_solution.m_points[0]);
      }
      else
      {
        now=m_solution.m_points[j].getDistance(m_list.m_points[i])
          + m_list.m_points[i].getDistance(m_solution.m_points[j+1])
          - m_solution.m_points[j].getDistance(m_solution.m_points[j+1]);
      }
      if(now<minn) {minn=now; crt=j;}
    }
    m_solution.addAfter(m_list.m_points[i],m_solution.m_points[crt].getName());
  }
  return;
}

TSPCycle& TSPSolver::getSolution() {
  return m_solution;
}


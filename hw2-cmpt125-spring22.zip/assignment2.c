#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "assignment2.h"


int add_term(const char* file_name, const char* word, const char* definition) {
  // implement me
  return 0;
}  



char* find_term(const char* file_name, const char* word) {
  // implement me
  return NULL;
}  



uint64_t fib3(unsigned int n) {
  // implement me
  return 0;
}



int count_tokens(const char* str) {
  // implement me
  return 0;
}  



char** get_tokens(const char* str) {
  // implement me
  return NULL;
}  

